import sys
import numpy
from algorithms.KNearestNeighbour import KNN
from algorithms.NaiveBayes import NaiveBayes

NaiveBayes(None,None)

print(3*2**2)
