def KNN(k, testing, training):
    return